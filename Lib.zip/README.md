# Linex Bot

A Node.js Discord bot for welcome messages, staff announcements, support tickets, reviews, suggestions, and server supporter roles.

## Setup

1. Install Node.js 18.17 or newer.
2. Create a Discord application and bot at <https://discord.com/developers/applications>.
3. Enable the **Server Members Intent**, **Server Presence Intent**, **Message Content Intent**, and **Voice States Intent** in the Developer Portal.
4. Copy `.env.example` to `.env` and fill in the bot token, application ID, and channel/role IDs.
5. Invite the bot with the `bot` and `applications.commands` scopes. It needs `Manage Channels`, `Manage Roles`, `Send Messages`, `Embed Links`, and `Read Message History` permissions.
6. Install and start:

```bash
npm install
npm start
```

For development with automatic restarts:

```bash
npm run dev
```

## Commands

- `/say message` posts an announcement in the current channel. Restricted to user `678596589543227393`.
- `/ticket-panel` posts the support ticket button. Staff only.
- `/toslib` posts the Linex guidelines and terms dropdown. Staff only.
- `/membercount` shows the total number of server members.
- `/review rating comment` submits a 1-to-10 review to `REVIEW_CHANNEL_ID`. Restricted to members with role `1525437119542071306`.
- `/serverinfo` shows only member, booster, channel, sticker, emoji, role, and boost counts.
- `/suggestion service suggestion` submits a numbered suggestion and discussion thread to `SUGGESTION_CHANNEL_ID`.
- `/update message` publishes a bot update to `UPDATES_CHANNEL_ID`. Staff only.
- `/supporter status` shows the configured supporter role.

New members receive a welcome message, and members who boost the server receive `SERVER_SUPPORTER_ROLE_ID`. Members who put `/linex` in their custom status receive `HONORABLE_MEMBER_ROLE_ID` and a supporter embed. When a boost is removed, the role is removed too.

Set `LOG_CHANNEL_ID` to receive audit-style embeds when members join or leave, join/leave/move between voice channels, edit/delete messages, channels are created/deleted/renamed, roles are created/deleted, or members are banned/unbanned. Set `SUPPORTER_CHANNEL_ID` to override the updates channel for supporter notices. Deleted message content may be unavailable when Discord did not cache the message.

## Discord permissions and intents

The bot requires the `Guilds`, `GuildMembers`, `GuildMessages`, `GuildVoiceStates`, `GuildPresences`, and `MessageContent` intents. Enable the privileged Server Members, Server Presence, and Message Content intents in the Developer Portal before starting it.

Channel IDs and role IDs are intentionally kept in `.env` so the same code can be reused across servers.
