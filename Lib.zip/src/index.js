require('dotenv').config();

const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  Client,
  EmbedBuilder,
  Events,
  ActivityType,
  ModalBuilder,
  PermissionsBitField,
  REST,
  Routes,
  SlashCommandBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  TextInputBuilder,
  TextInputStyle
} = require('discord.js');

const config = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.GUILD_ID,
  welcomeChannelId: process.env.WELCOME_CHANNEL_ID,
  logChannelId: process.env.LOG_CHANNEL_ID,
  updatesChannelId: process.env.UPDATES_CHANNEL_ID,
  supportCategoryId: process.env.SUPPORT_CATEGORY_ID,
  supportRoleId: process.env.SUPPORT_ROLE_ID,
  supporterChannelId: process.env.SUPPORTER_CHANNEL_ID,
  reviewChannelId: process.env.REVIEW_CHANNEL_ID,
  suggestionChannelId: process.env.SUGGESTION_CHANNEL_ID,
  moderationChannelId: process.env.MODERATION_CHANNEL_ID || process.env.LOG_CHANNEL_ID,
  supporterRoleId: process.env.SERVER_SUPPORTER_ROLE_ID,
  honorableMemberRoleId: process.env.HONORABLE_MEMBER_ROLE_ID || '1550050433676873748',
  spamMessageLimit: Number(process.env.SPAM_MESSAGE_LIMIT || 5),
  spamWindowMs: Number(process.env.SPAM_WINDOW_MS || 10000),
  spamTimeoutMinutes: Number(process.env.SPAM_TIMEOUT_MINUTES || 3),
  updateMessage: process.env.BOT_UPDATE_MESSAGE || 'Bot systems are online and ready.',
  ownerIds: (process.env.BOT_OWNER_IDS || '').split(',').map((id) => id.trim()).filter(Boolean)
};

const restrictedCommandUsers = {
  say: '678596589543227393'
};

const restrictedCommandRoles = {
  review: '1525437119542071306'
};

const ticketSupportRoleIds = [
  '1525437330956095559',
  '1525437094674300948'
];

const suggestionCounters = new Map();
const modLogEntries = new Map();
const spamTracker = new Map();

if (!config.token || !config.clientId) {
  console.error('Missing DISCORD_TOKEN or CLIENT_ID. Copy .env.example to .env and configure it.');
  process.exit(1);
}

const commands = [
  new SlashCommandBuilder().setName('say').setDescription('Send an announcement in this channel.')
    .addStringOption((option) => option.setName('message').setDescription('The announcement text.').setRequired(true)),
  new SlashCommandBuilder().setName('ticket-panel').setDescription('Post the support ticket panel.'),
  new SlashCommandBuilder().setName('review').setDescription('Submit a review.')
    .addIntegerOption((option) => option.setName('rating').setDescription('Rating from 1 to 10.').setMinValue(1).setMaxValue(10).setRequired(true))
    .addStringOption((option) => option.setName('comment').setDescription('Your review.').setMaxLength(1000).setRequired(true)),
  new SlashCommandBuilder().setName('suggestion').setDescription('Submit a server suggestion.')
    .addStringOption((option) => option.setName('service').setDescription('The service or bot this suggestion is for.').setMaxLength(100).setRequired(true))
    .addStringOption((option) => option.setName('suggestion').setDescription('Explain your suggestion.').setMaxLength(1500).setRequired(true)),
  new SlashCommandBuilder().setName('update').setDescription('Publish a bot update.')
    .addStringOption((option) => option.setName('message').setDescription('What changed?').setMaxLength(1500).setRequired(true)),
  new SlashCommandBuilder().setName('supporter').setDescription('Show server supporter information.')
    .addSubcommand((subcommand) => subcommand.setName('status').setDescription('Show the supporter role status.')),
  new SlashCommandBuilder().setName('toslib').setDescription('Post the Linex guidelines and terms menu.'),
  new SlashCommandBuilder().setName('membercount').setDescription('Show the server member count.'),
  new SlashCommandBuilder().setName('role').setDescription('View information about a role.')
    .addRoleOption((option) => option.setName('role').setDescription('The role to inspect.').setRequired(true)),
  new SlashCommandBuilder().setName('ban').setDescription('Ban a user from the server.')
    .addUserOption((option) => option.setName('user').setDescription('The user to ban.').setRequired(true))
    .addStringOption((option) => option.setName('reason').setDescription('Reason for the ban.').setMaxLength(512)),
  new SlashCommandBuilder().setName('kick').setDescription('Kick a user from the server.')
    .addUserOption((option) => option.setName('user').setDescription('The user to kick.').setRequired(true))
    .addStringOption((option) => option.setName('reason').setDescription('Reason for the kick.').setMaxLength(512)),
  new SlashCommandBuilder().setName('timeout').setDescription('Timeout a member.')
    .addUserOption((option) => option.setName('user').setDescription('The member to timeout.').setRequired(true))
    .addIntegerOption((option) => option.setName('minutes').setDescription('Timeout length in minutes.').setMinValue(1).setMaxValue(40320).setRequired(true))
    .addStringOption((option) => option.setName('reason').setDescription('Reason for the timeout.').setMaxLength(512)),
  new SlashCommandBuilder().setName('banner').setDescription('Get a user banner.')
    .addUserOption((option) => option.setName('user').setDescription('The user to inspect.').setRequired(true)),
  new SlashCommandBuilder().setName('avatar').setDescription('Get a user avatar.')
    .addUserOption((option) => option.setName('user').setDescription('The user to inspect.').setRequired(true)),
  new SlashCommandBuilder().setName('whois').setDescription('Get information about a user.')
    .addUserOption((option) => option.setName('user').setDescription('The user to inspect.').setRequired(true)),
  new SlashCommandBuilder().setName('purge').setDescription('Delete a number of recent messages.')
    .addIntegerOption((option) => option.setName('amount').setDescription('Number of messages to delete.').setMinValue(1).setMaxValue(100).setRequired(true)),
  new SlashCommandBuilder().setName('warn').setDescription('Warn a member.')
    .addUserOption((option) => option.setName('user').setDescription('The member to warn.').setRequired(true))
    .addStringOption((option) => option.setName('reason').setDescription('Reason for the warning.').setMaxLength(512).setRequired(true)),
  new SlashCommandBuilder().setName('unban').setDescription('Unban a user from the server.')
    .addUserOption((option) => option.setName('user').setDescription('The user to unban.').setRequired(true))
    .addStringOption((option) => option.setName('reason').setDescription('Reason for the unban.').setMaxLength(512)),
  new SlashCommandBuilder().setName('modlogs').setDescription('Show recent moderation actions.')
    .addIntegerOption((option) => option.setName('limit').setDescription('How many logs to show.').setMinValue(1).setMaxValue(10)),
  new SlashCommandBuilder().setName('serverinfo').setDescription('Show information about this server.')
].map((command) => command.toJSON());

const client = new Client({
  intents: ['Guilds', 'GuildMembers', 'GuildMessages', 'GuildVoiceStates', 'GuildPresences', 'MessageContent']
});

function isStaff(interaction) {
  return config.ownerIds.includes(interaction.user.id) || interaction.member?.permissions?.has(PermissionsBitField.Flags.ManageGuild);
}

function isOwnerOnly(interaction) {
  return config.ownerIds.includes(interaction.user.id) || interaction.user.id === restrictedCommandUsers.say;
}

function canUseRestrictedCommand(interaction, commandName) {
  if (restrictedCommandUsers[commandName]) return interaction.user.id === restrictedCommandUsers[commandName];
  return interaction.member?.roles?.cache.has(restrictedCommandRoles[commandName]) || false;
}

function stars(rating) {
  return `${'★'.repeat(rating)}${'☆'.repeat(5 - rating)}`;
}

async function registerCommands() {
  const rest = new REST({ version: '10' }).setToken(config.token);
  const route = config.guildId
    ? Routes.applicationGuildCommands(config.clientId, config.guildId)
    : Routes.applicationCommands(config.clientId);
  await rest.put(route, { body: commands });
  console.log(`Registered ${commands.length} slash commands${config.guildId ? ' in the development server' : ' globally'}.`);
}

async function sendToConfiguredChannel(guild, channelId, payload) {
  if (!channelId) return null;
  const channel = await guild.channels.fetch(channelId).catch(() => null);
  if (!channel?.isTextBased()) return null;
  return channel.send(payload);
}

async function sendLog(guild, title, description, color, fields = []) {
  if (!config.logChannelId) return null;
  return sendToConfiguredChannel(guild, config.logChannelId, {
    embeds: [new EmbedBuilder().setColor(0xe7ebf0).setTitle(title).setDescription(description).addFields(fields).setTimestamp()]
  });
}

async function getNextSuggestionNumber(guildId, channel) {
  if (!suggestionCounters.has(guildId)) {
    const messages = await channel.messages.fetch({ limit: 100 }).catch(() => new Map());
    const numbers = messages.map((message) => Number(message.embeds[0]?.title?.match(/^Suggestion #(\d+)$/)?.[1] || 0));
    suggestionCounters.set(guildId, Math.max(0, ...numbers) + 1);
  }
  const number = suggestionCounters.get(guildId);
  suggestionCounters.set(guildId, number + 1);
  return number;
}

async function sendSupporterMessage(member, role) {
  const channelId = config.supporterChannelId || config.updatesChannelId;
  if (!channelId) return null;
  const channel = await member.guild.channels.fetch(channelId).catch((error) => {
    console.error('Failed to find the supporter channel:', error);
    return null;
  });
  if (!channel?.isTextBased()) {
    console.error(`Supporter channel ${channelId} is missing or is not a text channel.`);
    return null;
  }
  return channel.send({
    content: `${member} ${role}`,
    allowedMentions: { users: [member.id], roles: [role.id] },
    embeds: [new EmbedBuilder()
      .setColor(0xe7ebf0)
      .setTitle('Linex — Server Supporter')
      .setDescription(`Thank you ${member} for putting \`/linex\` in your status! We have now awarded you with the ${role} role, which grants image permissions.`)]
  });
}

function hasSupporterStatus(presence) {
  return presence?.status !== 'offline' && presence?.activities?.some((activity) => activity.type === ActivityType.Custom && activity.state?.toLowerCase().includes('/linex'));
}

async function syncSupporterRole(member, hasStatus, notify) {
  const role = config.honorableMemberRoleId
    ? await member.guild.roles.fetch(config.honorableMemberRoleId).catch(() => null)
    : null;
  if (!role) return;

  if (!hasStatus) {
    if (member.roles.cache.has(role.id)) {
      await member.roles.remove(role).catch((error) => console.error('Failed to remove the supporter role:', error));
    }
    return;
  }

  if (member.roles.cache.has(role.id)) {
    if (notify) await sendSupporterMessage(member, role);
    return;
  }
  const added = await member.roles.add(role).then(() => true).catch((error) => {
    console.error('Failed to add the supporter role:', error);
    return false;
  });
  if (added && notify) await sendSupporterMessage(member, role);
}

async function syncExistingSupporters(client) {
  for (const guild of client.guilds.cache.values()) {
    const members = await guild.members.fetch().catch(() => guild.members.cache);
    for (const member of members.values()) {
      await syncSupporterRole(member, hasSupporterStatus(member.presence), false);
    }
  }
}

async function createTicket(interaction, category) {
  await interaction.deferReply({ ephemeral: true });
  const existing = interaction.guild.channels.cache.find((channel) => {
    const userOverwrite = channel.permissionOverwrites?.cache.get(interaction.user.id);
    return channel.topic === `ticket-owner:${interaction.user.id}` || channel.topic === 'Linex Support' && userOverwrite?.allow.has(PermissionsBitField.Flags.ViewChannel);
  });
  if (existing) {
    return interaction.editReply({ content: `You already have an open ticket: ${existing}` });
  }

  const roleIds = [...new Set([config.supportRoleId, ...ticketSupportRoleIds]
    .filter((roleId) => roleId && interaction.guild.roles.cache.has(roleId)))];
  const permissionOverwrites = [
    { id: interaction.guild.id, deny: [PermissionsBitField.Flags.ViewChannel] },
    { id: interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory] }
  ];
  permissionOverwrites.push(...roleIds.map((roleId) => ({
    id: roleId,
    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory]
  })));

  const supportCategory = config.supportCategoryId
    ? await interaction.guild.channels.fetch(config.supportCategoryId).catch(() => null)
    : null;
  if (config.supportCategoryId && supportCategory?.type !== ChannelType.GuildCategory) {
    console.warn(`SUPPORT_CATEGORY_ID ${config.supportCategoryId} is not a valid category. Creating the ticket without a parent.`);
  }

  const username = interaction.user.username
    .toLowerCase()
    .replace(/[^a-z0-9-_]/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '') || interaction.user.id;
  const ticket = await interaction.guild.channels.create({
    name: `ticket-${username}`,
    type: ChannelType.GuildText,
    parent: supportCategory?.type === ChannelType.GuildCategory ? supportCategory.id : undefined,
    topic: `ticket-owner:${interaction.user.id}`,
    permissionOverwrites
  });

  await interaction.editReply({ content: `Support ticket created: ${ticket}` });
  
  const closeButton = new ButtonBuilder().setCustomId('ticket-close').setLabel('Close ticket').setStyle(ButtonStyle.Danger);
  await ticket.send({
    content: [`<@${interaction.user.id}>`, ...roleIds.map((roleId) => `<@&${roleId}>`)].join(' '),
    allowedMentions: { users: [interaction.user.id], roles: roleIds },
    embeds: [new EmbedBuilder()
      .setColor(0xe7ebf0)
      .setTitle('Linex Support')
      .setDescription(`Hello ${interaction.user.username},\n\nPlease wait for a Customer Support Member to assist you with your ticket. Please describe what the reasoning for the ticket is today.`)
      .addFields({ name: 'Category', value: category === 'purchase' ? 'Purchase Support' : 'General Support' })],
    components: [new ActionRowBuilder().addComponents(closeButton)]
  }).catch((error) => console.error('Failed to send the ticket welcome message:', error));
}

function createPrivateInfoEmbed(title, description) {
  return new EmbedBuilder().setColor(0xe7ebf0).setTitle(title).setDescription(description);
}

function createTermsMenu() {
  return new StringSelectMenuBuilder()
    .setCustomId('support-category')
    .setPlaceholder('Select an option')
    .addOptions(
      new StringSelectMenuOptionBuilder().setLabel('Community Guidelines').setDescription('View the Linex community rules.').setValue('guidelines'),
      new StringSelectMenuOptionBuilder().setLabel('Terms of Service').setDescription('View the Linex terms of service.').setValue('tos')
    );
}

function createTicketMenu() {
  return new StringSelectMenuBuilder()
    .setCustomId('support-ticket-category')
    .setPlaceholder('Choose a category...')
    .addOptions(
      new StringSelectMenuOptionBuilder().setLabel('General Support').setDescription('Questions about usage, features, or existing services.').setValue('general'),
      new StringSelectMenuOptionBuilder().setLabel('Purchase Support').setDescription('Questions about purchasing a service or an order.').setValue('purchase')
    );
}

function createTicketPanelEmbed() {
  return new EmbedBuilder()
    .setColor(0xe7ebf0)
    .setTitle('Linex Support')
    .setDescription("Welcome to Linex' support system! If you need assistance or would like to purchase a bot, please select a category below.\n\n**General Support** - For questions about general usage, features or updates to your existing services.\n\n**Purchase Support** - If you are looking to purchase a service or talk about an order.");
}

function createTermsPanelEmbed() {
  return new EmbedBuilder()
    .setColor(0xe7ebf0)
    .setTitle('Linex')
    .setDescription('Welcome to Linex! To ensure a smooth experience, please read through our **Community Guidelines** and **Terms of Service** before purchasing any services.\n\nNeed assistance? Open a ticket in our support channel anytime.');
}

function formatDurationMinutes(minutes) {
  if (!Number.isFinite(minutes) || minutes <= 0) return '0 minutes';
  const chunks = [];
  const days = Math.floor(minutes / 1440);
  const hours = Math.floor((minutes % 1440) / 60);
  const remainingMinutes = minutes % 60;
  if (days) chunks.push(`${days} day${days === 1 ? '' : 's'}`);
  if (hours) chunks.push(`${hours} hour${hours === 1 ? '' : 's'}`);
  if (remainingMinutes || chunks.length === 0) chunks.push(`${remainingMinutes} minute${remainingMinutes === 1 ? '' : 's'}`);
  return chunks.join(', ');
}

function createUserInfoEmbed(user, member) {
  const safeUser = user ?? member?.user;
  if (!safeUser) return null;

  const helper = new EmbedBuilder()
    .setColor(0xe7ebf0)
    .setTitle(`${safeUser.tag}`)
    .setThumbnail(safeUser.displayAvatarURL({ extension: 'png', size: 256 }))
    .setDescription(`**ID:** ${safeUser.id}`)
    .addFields(
      { name: 'Account created', value: `<t:${Math.floor((safeUser.createdTimestamp || Date.now()) / 1000)}:F>`, inline: true }
    );

  if (member) {
    const roles = member.roles.cache.filter((role) => role.id !== member.guild.id).sort((a, b) => b.position - a.position);
    helper.addFields(
      { name: 'Joined server', value: member.joinedAt ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:F>` : 'Unknown', inline: true },
      { name: 'Roles', value: roles.size ? roles.map((role) => role.toString()).slice(0, 10).join(', ') : 'None', inline: false },
      { name: 'Boosting', value: member.premiumSince ? 'Yes' : 'No', inline: true }
    );
  }

  return helper;
}

function appendModLog(guildId, action, details) {
  const guildLogs = modLogEntries.get(guildId) || [];
  guildLogs.unshift({ action, details, timestamp: Date.now() });
  modLogEntries.set(guildId, guildLogs.slice(0, 25));
}

function getModLogEntries(guildId, limit = 5) {
  return (modLogEntries.get(guildId) || []).slice(0, limit);
}

async function sendModerationLog(guild, user, action, reason, moderator = 'Auto Moderation') {
  if (!config.moderationChannelId) return null;
  const channel = await guild.channels.fetch(config.moderationChannelId).catch(() => null);
  if (!channel?.isTextBased()) return null;
  const entry = {
    action,
    moderator,
    user: user ? `${user.tag} (${user.id})` : 'Unknown',
    reason,
    timestamp: Date.now()
  };
  appendModLog(guild.id, action, `${entry.user} — ${reason} — ${moderator}`);
  return channel.send({
    embeds: [new EmbedBuilder()
      .setColor(0xe7ebf0)
      .setTitle('Moderation action')
      .setDescription(`**Action:** ${action}\n**User:** ${entry.user}\n**Moderator:** ${moderator}\n**Reason:** ${reason}`)
      .setTimestamp()]
  });
}

const communityGuidelines = [
  '**1. - Following Discord\'s Terms of Service**\nWhen you join our community, you must follow Discord\'s Terms of Service. This keeps our space safe for everyone. Breaking Discord\'s ToS can lead to action on your account.',
  '**2. - Swearing and Slurs**\nPlease limit slurs and excessive swearing. Targeting someone with slurs or engaging in hateful speech will not be tolerated and can result in enforcement.',
  '**3. - Not Safe For Work Content**\nNSFW content is not allowed in our server channels. Posting this material will lead to immediate removal and further actions.',
  '**4. - Avoid Drama and Conflict**\nStarting arguments or stirring drama is not allowed. Ongoing issues may result in timeouts. We suggest resolving disputes via direct messages.',
  '**5. - Protect Personal Information**\nSharing your own or someone else\'s personal information in our channels is strictly forbidden. Doing this will lead to immediate removal and further consequences.',
  '**6. - Harassment and Offensive Comments**\nHarassing others or making offensive comments about someone is not acceptable. This behavior will lead to enforcement actions.',
  '**7. - No Self Promotion**\nYou cannot post links to promote yourself or others. Violating this rule will result in enforcement.',
  '**8. - No Spam or Flooding**\nSpamming messages, emojis, or flooding the chat disrupts the community. Repeated offenses may lead to timeouts or removal.',
  '**9. - Use Appropriate Channels**\nKeep conversations in their designated channels. Posting in the wrong area may result in warnings or removal of your content.',
  '**10. - No Inappropriate Usernames or Avatars**\nUsernames or profile pictures that are offensive, NSFW, or otherwise inappropriate will be removed, and enforcement actions may follow.'
].join('\n\n');

const termsOfService = [
  '**1. - Payment Requirements**\nAll payments for Linex services are non-refundable. We reserve the right to suspend your service at any time if payments are not received. All payments are required up front before any service is provided.',
  '**2. - Developer Respect**\nOur developers work hard to provide custom bots tailored to your needs. Disrespecting our developers can result in a suspension of your service.',
  '**3. - Misuse of Services**\nUsing our services to raid or otherwise harm other servers or users is strictly prohibited. Caught violating these terms will result in an immediate termination of your service.',
  '**4. - Data Loss**\nLinex is not held liable for any data loss occurring on our Discord bots, nor for any damages or inconveniences from such an event.'
].join('\n\n');

client.once(Events.ClientReady, async (readyClient) => {
  console.log(`Logged in as ${readyClient.user.tag}`);
  await registerCommands();
  await syncExistingSupporters(readyClient);
  if (config.updatesChannelId && config.updateMessage) {
    await sendToConfiguredChannel(readyClient.guilds.cache.first(), config.updatesChannelId, {
      embeds: [new EmbedBuilder().setColor(0xe7ebf0).setTitle('Bot update').setDescription(config.updateMessage).setTimestamp()]
    });
  }
});

client.on(Events.GuildMemberAdd, async (member) => {
  await sendToConfiguredChannel(member.guild, config.welcomeChannelId, {
    content: `> :wave: **Welcome ${member} to Linex Systems**`
  });
  const memberAvatar = member.user.displayAvatarURL({ extension: 'png', size: 256 });
  await sendLog(member.guild, 'Member joined', `${member} joined the server.`, 0xe7ebf0, [
    { name: 'User', value: `${member.user.tag} (${member.id})` }
  ]).then((logMessage) => {
    if (logMessage) {
      const embed = logMessage.embeds?.[0];
      if (embed) {
        embed.setImage(memberAvatar);
        return logMessage.edit({ embeds: [embed] }).catch(() => null);
      }
    }
    return null;
  }).catch(() => null);
});

client.on(Events.GuildMemberRemove, async (member) => {
  await sendLog(member.guild, 'Member left', `${member.user} left the server.`, 0xe7ebf0, [
    { name: 'User', value: `${member.user.tag} (${member.id})` }
  ]);
});

client.on(Events.GuildMemberUpdate, async (oldMember, newMember) => {
  if (!config.supporterRoleId || oldMember.premiumSince === newMember.premiumSince) return;
  const role = newMember.guild.roles.cache.get(config.supporterRoleId);
  if (!role) return;
  if (!oldMember.premiumSince && newMember.premiumSince) {
    await newMember.roles.add(role).catch(() => null);
    await sendToConfiguredChannel(newMember.guild, config.updatesChannelId, { content: `${newMember} just boosted the server. Thank you for supporting us!` });
  } else if (oldMember.premiumSince && !newMember.premiumSince) {
    await newMember.roles.remove(role).catch(() => null);
  }
});

client.on(Events.PresenceUpdate, async (oldPresence, newPresence) => {
  const member = newPresence.member || oldPresence?.member || await newPresence.guild.members.fetch(newPresence.userId).catch(() => null);
  if (!member) return;
  const hadSupporterStatus = hasSupporterStatus(oldPresence);
  const hasStatus = hasSupporterStatus(newPresence);
  await syncSupporterRole(member, hasStatus, hasStatus && !hadSupporterStatus);
});

client.on(Events.VoiceStateUpdate, async (oldState, newState) => {
  const member = newState.member || oldState.member;
  if (!member || oldState.channelId === newState.channelId) return;

  if (!oldState.channelId && newState.channelId) {
    return sendLog(member.guild, 'Voice channel joined', `${member} joined <#${newState.channelId}>.`, 0xe7ebf0);
  }
  if (oldState.channelId && !newState.channelId) {
    return sendLog(member.guild, 'Voice channel left', `${member} left <#${oldState.channelId}>.`, 0xe7ebf0);
  }
  return sendLog(member.guild, 'Voice channel changed', `${member} moved from <#${oldState.channelId}> to <#${newState.channelId}>.`, 0xe7ebf0);
});

client.on(Events.ChannelCreate, async (channel) => {
  if (!channel.guild) return;
  await sendLog(channel.guild, 'Channel created', `#${channel.name} was created.`, 0xe7ebf0, [
    { name: 'Channel ID', value: channel.id }
  ]);
});

client.on(Events.ChannelDelete, async (channel) => {
  if (!channel.guild) return;
  await sendLog(channel.guild, 'Channel deleted', `#${channel.name} was deleted.`, 0xe7ebf0, [
    { name: 'Channel ID', value: channel.id }
  ]);
});

client.on(Events.ChannelUpdate, async (oldChannel, newChannel) => {
  if (!newChannel.guild || oldChannel.name === newChannel.name) return;
  await sendLog(newChannel.guild, 'Channel renamed', `#${oldChannel.name} was renamed to #${newChannel.name}.`, 0xe7ebf0, [
    { name: 'Channel ID', value: newChannel.id }
  ]);
});

client.on(Events.RoleCreate, async (role) => {
  await sendLog(role.guild, 'Role created', `The **${role.name}** role was created.`, 0xe7ebf0, [
    { name: 'Role ID', value: role.id }
  ]);
});

client.on(Events.RoleDelete, async (role) => {
  await sendLog(role.guild, 'Role deleted', `The **${role.name}** role was deleted.`, 0xe7ebf0, [
    { name: 'Role ID', value: role.id }
  ]);
});

client.on(Events.GuildBanAdd, async (ban) => {
  await sendLog(ban.guild, 'Member banned', `${ban.user} was banned from the server.`, 0xe7ebf0, [
    { name: 'User', value: `${ban.user.tag} (${ban.user.id})` },
    { name: 'Reason', value: ban.reason || 'No reason provided.' }
  ]);
});

client.on(Events.GuildBanRemove, async (ban) => {
  await sendLog(ban.guild, 'Member unbanned', `${ban.user} was unbanned from the server.`, 0xe7ebf0, [
    { name: 'User', value: `${ban.user.tag} (${ban.user.id})` }
  ]);
});

client.on(Events.MessageDelete, async (message) => {
  if (!message.guild || message.author?.bot) return;
  const author = message.author ? `${message.author} (${message.author.tag})` : 'Unknown user';
  const content = message.content?.trim() || 'Message content was unavailable.';
  await sendLog(message.guild, 'Message deleted', `${author} deleted a message in <#${message.channelId}>.`, 0xe7ebf0, [
    { name: 'Content', value: content.slice(0, 1024) }
  ]);
});

client.on(Events.MessageUpdate, async (oldMessage, newMessage) => {
  if (!newMessage.guild || newMessage.author?.bot || oldMessage.content === newMessage.content) return;
  const author = newMessage.author ? `${newMessage.author} (${newMessage.author.tag})` : 'Unknown user';
  await sendLog(newMessage.guild, 'Message edited', `${author} edited a message in <#${newMessage.channelId}>.`, 0xe7ebf0, [
    { name: 'Before', value: (oldMessage.content || 'Message content was unavailable.').slice(0, 1024) },
    { name: 'After', value: (newMessage.content || 'Message content was unavailable.').slice(0, 1024) }
  ]);
});

client.on(Events.MessageCreate, async (message) => {
  if (!message.guild || message.author.bot) return;
  const member = message.member;
  if (!member || member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) return;

  const key = `${message.guild.id}:${message.author.id}`;
  const now = Date.now();
  const timestamps = spamTracker.get(key) || [];
  const recent = timestamps.filter((time) => now - time < config.spamWindowMs);
  recent.push(now);
  spamTracker.set(key, recent);

  if (recent.length >= config.spamMessageLimit) {
    try {
      await member.timeout(config.spamTimeoutMinutes * 60 * 1000, 'Automatic timeout: spam detected.');
      await message.delete().catch(() => null);
      await sendModerationLog(message.guild, message.author, 'Auto-timeout', `Spam detected: ${recent.length} messages in ${config.spamWindowMs / 1000} seconds.`, 'Auto Moderation');
      await message.channel.send({ content: `${member} was timed out for ${config.spamTimeoutMinutes} minutes for spamming.`, allowedMentions: { users: [member.id] } }).catch(() => null);
    } catch (error) {
      console.error('Failed to auto-timeout spammer:', error);
    }
    spamTracker.delete(key);
  }
});

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (interaction.isStringSelectMenu()) {
      if (interaction.customId === 'support-ticket-category') {
        return await createTicket(interaction, interaction.values[0]);
      }
      if (interaction.customId === 'support-category') {
        const selected = interaction.values[0];
        if (selected === 'guidelines') return interaction.reply({ embeds: [createPrivateInfoEmbed('Community Guidelines', communityGuidelines)], ephemeral: true });
        return interaction.reply({ embeds: [createPrivateInfoEmbed('Terms of Service', termsOfService)], ephemeral: true });
      }
    }
    if (interaction.isButton()) {
      if (interaction.customId === 'ticket-open') return await createTicket(interaction);
      if (interaction.customId === 'purchase-ticket') return await createTicket(interaction, 'purchase');
      if (interaction.customId === 'ticket-close') {
        await interaction.reply('This ticket will close in a moment.');
        return setTimeout(() => interaction.channel.delete().catch(() => null), 3000);
      }
      if (interaction.customId.startsWith('suggestion-')) {
        const [_, direction, messageId] = interaction.customId.split('-');
        const message = await interaction.channel.messages.fetch(messageId).catch(() => null);
        if (!message) return interaction.reply({ content: 'That suggestion is no longer available.', ephemeral: true });
        const current = message.embeds[0]?.fields?.find((field) => field.name === 'Votes')?.value || '0 / 0';
        const [up, down] = current.split('/').map((value) => Number(value.trim()) || 0);
        const updated = direction === 'up' ? `${up + 1} / ${down}` : `${up} / ${down + 1}`;
        const embed = EmbedBuilder.from(message.embeds[0]).setFields({ name: 'Votes', value: updated, inline: true });
        return interaction.update({ embeds: [embed] });
      }
    }

    if (!interaction.isChatInputCommand()) return;
    if (interaction.commandName === 'say') {
      if (!canUseRestrictedCommand(interaction, 'say')) return interaction.reply({ content: 'You are not allowed to use this command.', ephemeral: true });
      await interaction.channel.send({ content: interaction.options.getString('message') });
      return interaction.reply({ content: 'Announcement sent.', ephemeral: true });
    }
    if (interaction.commandName === 'ticket-panel' || interaction.commandName === 'toslib') {
      if (!isStaff(interaction)) return interaction.reply({ content: 'You need Manage Server permission to use this command.', ephemeral: true });
      const isTicketPanel = interaction.commandName === 'ticket-panel';
      await interaction.channel.send({
        embeds: [isTicketPanel ? createTicketPanelEmbed() : createTermsPanelEmbed()],
        components: [new ActionRowBuilder().addComponents(isTicketPanel ? createTicketMenu() : createTermsMenu())]
      });
      return interaction.reply({ content: isTicketPanel ? 'Ticket panel posted.' : 'Guidelines and terms panel posted.', ephemeral: true });
    }
    if (interaction.commandName === 'review') {
      if (!canUseRestrictedCommand(interaction, 'review')) return interaction.reply({ content: 'You are not allowed to use this command.', ephemeral: true });
      const rating = interaction.options.getInteger('rating');
      const channel = await sendToConfiguredChannel(interaction.guild, config.reviewChannelId, { embeds: [new EmbedBuilder().setColor(0xe7ebf0).setTitle('Linex Review').addFields(
        { name: 'Review submitted by', value: `${interaction.user}` },
        { name: 'Rating', value: `${rating}/10` },
        { name: 'Review', value: interaction.options.getString('comment') }
      ).setFooter({ text: 'Thank you for leaving a review!' })] });
      return interaction.reply({ content: channel ? 'Thanks, your review was submitted.' : 'The review system is not configured yet.', ephemeral: true });
    }
    if (interaction.commandName === 'suggestion') {
      const channel = await interaction.guild.channels.fetch(config.suggestionChannelId).catch(() => null);
      if (!channel?.isTextBased()) return interaction.reply({ content: 'The suggestion system is not configured yet.', ephemeral: true });
      const suggestionNumber = await getNextSuggestionNumber(interaction.guild.id, channel);
      const embed = new EmbedBuilder().setColor(0xe7ebf0).setTitle(`Suggestion #${suggestionNumber}`).addFields(
        { name: 'Suggestion submitted by', value: `${interaction.user}` },
        { name: 'Service', value: interaction.options.getString('service') },
        { name: 'Suggestion', value: interaction.options.getString('suggestion') }
      ).setFooter({ text: 'Thank you for your feedback! Please use the thread below to discuss this suggestion with our team.' });
      const message = await channel.send({ embeds: [embed] });
      await message.startThread({ name: `Suggestion #${suggestionNumber} discussion`, autoArchiveDuration: 10080 }).catch(() => null);
      return interaction.reply({ content: 'Your suggestion was submitted.', ephemeral: true });
    }
    if (interaction.commandName === 'update') {
      if (!isStaff(interaction)) return interaction.reply({ content: 'You need Manage Server permission to use this command.', ephemeral: true });
      const sent = await sendToConfiguredChannel(interaction.guild, config.updatesChannelId, { embeds: [new EmbedBuilder().setColor(0xe7ebf0).setTitle('Bot update').setDescription(interaction.options.getString('message')).setFooter({ text: `Posted by ${interaction.user.username}` }).setTimestamp()] });
      return interaction.reply({ content: sent ? 'Update published.' : 'The updates channel is not configured yet.', ephemeral: true });
    }
    if (interaction.commandName === 'supporter') {
      const role = config.supporterRoleId ? interaction.guild.roles.cache.get(config.supporterRoleId) : null;
      return interaction.reply({ content: role ? `Server supporters receive the ${role} role when they boost the server.` : 'The server supporter role is not configured yet.', ephemeral: true });
    }
    if (interaction.commandName === 'role') {
      if (!isOwnerOnly(interaction)) return interaction.reply({ content: 'This command is restricted to the bot owner.', ephemeral: true });
      const targetRole = interaction.options.getRole('role');
      const roleInfoEmbed = new EmbedBuilder()
        .setColor(targetRole.color || 0xe7ebf0)
        .setTitle(targetRole.name)
        .setDescription(`**ID:** ${targetRole.id}\n**Mention:** ${targetRole}\n**Members:** ${targetRole.members.size}`)
        .addFields(
          { name: 'Color', value: targetRole.hexColor || 'Default', inline: true },
          { name: 'Hoisted', value: targetRole.hoist ? 'Yes' : 'No', inline: true },
          { name: 'Mentionable', value: targetRole.mentionable ? 'Yes' : 'No', inline: true },
          { name: 'Position', value: `${targetRole.position}`, inline: true }
        );
      return interaction.reply({ embeds: [roleInfoEmbed] });
    }
    if (interaction.commandName === 'ban') {
      if (!isOwnerOnly(interaction)) return interaction.reply({ content: 'This command is restricted to the bot owner.', ephemeral: true });
      const targetUser = interaction.options.getUser('user');
      const reason = interaction.options.getString('reason') || 'No reason provided.';
      const member = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
      await interaction.guild.bans.create(targetUser.id, { reason, deleteMessageSeconds: 604800 }).catch(() => null);
      if (member) await member.ban({ reason, deleteMessageSeconds: 604800 }).catch(() => null);
      await sendModerationLog(interaction.guild, targetUser, 'Ban', reason, `${interaction.user.tag} (${interaction.user.id})`);
      return interaction.reply({ content: `${targetUser} has been banned.`, ephemeral: true });
    }
    if (interaction.commandName === 'kick') {
      if (!isOwnerOnly(interaction)) return interaction.reply({ content: 'This command is restricted to the bot owner.', ephemeral: true });
      const targetUser = interaction.options.getUser('user');
      const reason = interaction.options.getString('reason') || 'No reason provided.';
      const member = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
      if (!member) return interaction.reply({ content: 'That user is not a member of this server.', ephemeral: true });
      await member.kick(reason);
      await sendModerationLog(interaction.guild, targetUser, 'Kick', reason, `${interaction.user.tag} (${interaction.user.id})`);
      return interaction.reply({ content: `${targetUser} has been kicked.`, ephemeral: true });
    }
    if (interaction.commandName === 'timeout') {
      if (!isOwnerOnly(interaction)) return interaction.reply({ content: 'This command is restricted to the bot owner.', ephemeral: true });
      const targetUser = interaction.options.getUser('user');
      const minutes = interaction.options.getInteger('minutes');
      const reason = interaction.options.getString('reason') || 'No reason provided.';
      const member = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
      if (!member) return interaction.reply({ content: 'That user is not a member of this server.', ephemeral: true });
      await member.timeout(minutes * 60 * 1000, reason).catch((error) => {
        console.error('Timeout failed:', error);
      });
      await sendModerationLog(interaction.guild, targetUser, 'Timeout', `${reason} (${formatDurationMinutes(minutes)})`, `${interaction.user.tag} (${interaction.user.id})`);
      return interaction.reply({ content: `${targetUser} has been timed out for ${formatDurationMinutes(minutes)}.`, ephemeral: true });
    }
    if (interaction.commandName === 'banner') {
      const targetUser = interaction.options.getUser('user');
      const user = await interaction.client.users.fetch(targetUser.id).catch(() => targetUser);
      const bannerUrl = user.bannerURL({ size: 4096, format: 'png', dynamic: true });
      if (!bannerUrl) return interaction.reply({ content: `${targetUser} does not have a banner.`, ephemeral: true });
      const bannerEmbed = new EmbedBuilder()
        .setColor(0xe7ebf0)
        .setTitle(`${targetUser.tag}'s banner`)
        .setImage(bannerUrl);
      return interaction.reply({ embeds: [bannerEmbed] });
    }
    if (interaction.commandName === 'avatar') {
      const targetUser = interaction.options.getUser('user');
      const user = await interaction.client.users.fetch(targetUser.id).catch(() => targetUser);
      const avatarUrl = user.displayAvatarURL({ size: 4096, dynamic: true });
      const avatarEmbed = new EmbedBuilder()
        .setColor(0xe7ebf0)
        .setTitle(`${targetUser.tag}'s avatar`)
        .setImage(avatarUrl);
      return interaction.reply({ embeds: [avatarEmbed] });
    }
    if (interaction.commandName === 'whois') {
      const targetUser = interaction.options.getUser('user');
      const user = await interaction.client.users.fetch(targetUser.id).catch(() => targetUser);
      const member = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
      const infoEmbed = createUserInfoEmbed(user, member);
      if (!infoEmbed) return interaction.reply({ content: 'I could not load that user.', ephemeral: true });
      return interaction.reply({ embeds: [infoEmbed] });
    }
    if (interaction.commandName === 'purge') {
      if (!isOwnerOnly(interaction)) return interaction.reply({ content: 'This command is restricted to the bot owner.', ephemeral: true });
      const amount = interaction.options.getInteger('amount');
      const messages = await interaction.channel.messages.fetch({ limit: amount }).catch(() => null);
      if (!messages || messages.size === 0) return interaction.reply({ content: 'No messages were found to delete.', ephemeral: true });
      await interaction.channel.bulkDelete(messages, true).catch((error) => {
        console.error('Purge failed:', error);
      });
      appendModLog(interaction.guild.id, 'Purge', `Deleted ${messages.size} messages in ${interaction.channel}`);
      return interaction.reply({ content: `Deleted ${messages.size} messages.`, ephemeral: true });
    }
    if (interaction.commandName === 'warn') {
      if (!isOwnerOnly(interaction)) return interaction.reply({ content: 'This command is restricted to the bot owner.', ephemeral: true });
      const targetUser = interaction.options.getUser('user');
      const reason = interaction.options.getString('reason');
      await interaction.deferReply({ ephemeral: true });
      await targetUser.send({
        embeds: [new EmbedBuilder()
          .setColor(0xe7ebf0)
          .setTitle('Warning notice')
          .setDescription(`You have been warned in ${interaction.guild.name}.\n\n**Reason:** ${reason}`)
          .setTimestamp()]
      }).catch((error) => console.error('Warning DM failed:', error));
      await sendModerationLog(interaction.guild, targetUser, 'Warn', reason, `${interaction.user.tag} (${interaction.user.id})`)
        .catch((error) => console.error('Warning moderation log failed:', error));
      return interaction.editReply({ content: `${targetUser} has been warned for: ${reason}` });
    }
    if (interaction.commandName === 'unban') {
      if (!isOwnerOnly(interaction)) return interaction.reply({ content: 'This command is restricted to the bot owner.', ephemeral: true });
      const targetUser = interaction.options.getUser('user');
      const reason = interaction.options.getString('reason') || 'No reason provided.';
      await interaction.guild.bans.remove(targetUser.id, reason).catch((error) => {
        console.error('Unban failed:', error);
      });
      await sendModerationLog(interaction.guild, targetUser, 'Unban', reason, `${interaction.user.tag} (${interaction.user.id})`);
      return interaction.reply({ content: `${targetUser} has been unbanned.`, ephemeral: true });
    }
    if (interaction.commandName === 'modlogs') {
      if (!isOwnerOnly(interaction)) return interaction.reply({ content: 'This command is restricted to the bot owner.', ephemeral: true });
      const limit = interaction.options.getInteger('limit') || 5;
      const entries = getModLogEntries(interaction.guild.id, limit);
      if (!entries.length) return interaction.reply({ content: 'There are no recent moderation logs yet.', ephemeral: true });
      const embed = new EmbedBuilder()
        .setColor(0xe7ebf0)
        .setTitle('Recent moderation logs')
        .setDescription(entries.map((entry) => `**${entry.action}** — ${entry.details} (${new Date(entry.timestamp).toLocaleString()})`).join('\n'));
      return interaction.reply({ embeds: [embed] });
    }
    if (interaction.commandName === 'membercount') {
      const memberCountEmbed = new EmbedBuilder()
        .setColor(0xe7ebf0)
        .setTitle('Members')
        .setDescription(`${interaction.guild.memberCount}`)
        .setTimestamp();
      return interaction.reply({ embeds: [memberCountEmbed] });
    }
    if (interaction.commandName === 'serverinfo') {
      const guild = await interaction.guild.fetch();
      const owner = await guild.fetchOwner().catch(() => null);
      const channels = guild.channels.cache;
      const categories = channels.filter((channel) => channel.type === ChannelType.GuildCategory).size;
      const textChannels = channels.filter((channel) => [ChannelType.GuildText, ChannelType.GuildAnnouncement, ChannelType.GuildForum, ChannelType.GuildMedia].includes(channel.type)).size;
      const voiceChannels = channels.filter((channel) => [ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(channel.type)).size;
      const createdTimestamp = Math.floor(guild.createdTimestamp / 1000);
      const iconUrl = guild.iconURL({ extension: 'png', size: 256 });
      const bannerUrl = guild.bannerURL({ extension: 'png', size: 1024 }) || iconUrl;
      const premiumTier = guild.premiumTier ?? 0;
      const boostLevel = premiumTier === 0 || premiumTier === 'NONE' ? 0 : String(premiumTier).replace('TIER_', '');
      const embed = new EmbedBuilder()
        .setColor(0xe7ebf0)
        .setTitle(guild.name)
        .setDescription(`**Server Owner**\n${owner ? `${owner.user.username} — ${owner.id}` : guild.ownerId}\n\n**Created**\n<t:${createdTimestamp}:D> (<t:${createdTimestamp}:R>)`)
        .addFields(
          { name: 'Members', value: `Total: ${guild.memberCount}\nBoosters: ${guild.premiumSubscriptionCount || 0}`, inline: true },
          { name: 'Channels', value: `Categories: ${categories}\nText: ${textChannels}\nVoice: ${voiceChannels}`, inline: true },
          { name: 'Assets', value: `Stickers: ${guild.stickers.cache.size}\nEmojis: ${guild.emojis.cache.size}\nRoles: ${guild.roles.cache.size}`, inline: true },
          { name: 'Boosts', value: `Level: ${boostLevel}\nBoosts: ${guild.premiumSubscriptionCount || 0}`, inline: false }
        )
        .setFooter({ text: `Server ID: ${guild.id}` });
      if (iconUrl) embed.setThumbnail(iconUrl);
      if (bannerUrl) embed.setImage(bannerUrl);
      return interaction.reply({ embeds: [embed] });
    }
  } catch (error) {
    console.error(error);
    const response = { content: 'Something went wrong while handling that request.', ephemeral: true };
    if (interaction.replied || interaction.deferred) await interaction.followUp(response).catch(() => null);
    else await interaction.reply(response).catch(() => null);
  }
});

client.login(config.token);
