const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
require('dotenv').config();

const port = Number(process.env.PORT || 3000);
const publicUrl = process.env.PUBLIC_URL || `http://localhost:${port}`;
const gamePassId = process.env.ROBLOX_GAME_PASS_ID || '1986110731';
const sessionSecret = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const page = path.join(__dirname, 'public', 'index.html');
const dashboardPage = path.join(__dirname, 'public', 'dashboard.html');
const publicDirectory = path.join(__dirname, 'public');
const dataDirectory = path.join(__dirname, 'data');
const configFile = path.join(dataDirectory, 'bot-config.json');
const activityFile = path.join(dataDirectory, 'activity.json');

fs.mkdirSync(dataDirectory, { recursive: true });

function sendJson(response, status, payload, headers = {}) {
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', ...headers });
  response.end(JSON.stringify(payload));
}

function createPaymentSession(userId) {
  const payload = Buffer.from(JSON.stringify({ userId, expiresAt: Date.now() + 86400000 })).toString('base64url');
  const signature = crypto.createHmac('sha256', sessionSecret).update(payload).digest('base64url');
  return `${payload}.${signature}`;
}

function hasValidPaymentSession(request) {
  const cookies = Object.fromEntries((request.headers.cookie || '').split(';').map((part) => part.trim().split('=').map(decodeURIComponent)).filter(([key]) => key));
  const session = cookies.linex_payment;
  if (!session) return false;
  const [payload, signature] = session.split('.');
  if (!payload || !signature) return false;
  const expected = crypto.createHmac('sha256', sessionSecret).update(payload).digest('base64url');
  if (signature.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return false;
  try {
    return JSON.parse(Buffer.from(payload, 'base64url').toString()).expiresAt > Date.now();
  } catch {
    return false;
  }
}

function readConfig() {
  try {
    return JSON.parse(fs.readFileSync(configFile, 'utf8'));
  } catch {
    return { bot: true, welcome: true, embeds: true, startup: true };
  }
}

function readActivity() {
  try {
    return JSON.parse(fs.readFileSync(activityFile, 'utf8'));
  } catch {
    return [];
  }
}

function recordActivity(entry) {
  const activity = [{ ...entry, when: new Date().toISOString() }, ...readActivity()].slice(0, 100);
  fs.writeFileSync(activityFile, JSON.stringify(activity, null, 2));
  return activity;
}

function readRequestBody(request) {
  return new Promise((resolve, reject) => {
    let body = '';
    request.on('data', (chunk) => {
      body += chunk;
      if (body.length > 100_000) request.destroy(new Error('Request body too large'));
    });
    request.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch {
        reject(new Error('Request body must be valid JSON'));
      }
    });
    request.on('error', reject);
  });
}

http.createServer((request, response) => {
  const requestPath = new URL(request.url, `http://${request.headers.host || 'localhost'}`).pathname;

  if (requestPath.startsWith('/assets/')) {
    const assetPath = path.join(publicDirectory, requestPath.slice('/'.length));
    if (!assetPath.startsWith(path.join(publicDirectory, 'assets'))) {
      response.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
      response.end('Invalid asset path');
      return;
    }
    fs.readFile(assetPath, (error, content) => {
      if (error) {
        response.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        response.end('Asset not found');
        return;
      }
      const contentType = assetPath.endsWith('.png') ? 'image/png' : 'application/octet-stream';
      response.writeHead(200, { 'Content-Type': contentType, 'Cache-Control': 'public, max-age=3600' });
      response.end(content);
    });
    return;
  }

  if (requestPath === '/api/config' && request.method === 'GET') {
    sendJson(response, 200, readConfig());
    return;
  }

  if (requestPath === '/api/activity' && request.method === 'GET') {
    sendJson(response, 200, readActivity());
    return;
  }

  if (requestPath === '/api/payment/check' && request.method === 'GET') {
    const userId = new URL(request.url, `http://${request.headers.host || 'localhost'}`).searchParams.get('userId');
    if (!/^\d+$/.test(userId || '')) {
      sendJson(response, 400, { owned: false, error: 'Enter a valid Roblox user ID.' });
      return;
    }
    fetch(`https://inventory.roblox.com/v1/users/${userId}/items/GamePass/${gamePassId}`)
      .then((robloxResponse) => robloxResponse.ok ? robloxResponse.json() : Promise.reject(new Error('Roblox could not verify that user.')))
      .then((payload) => {
        const owned = Array.isArray(payload.data) && payload.data.length > 0;
        if (owned) recordActivity({ person: `Roblox user ${userId}`, action: 'Verified Game Pass purchase', target: `Game Pass ${gamePassId}` });
        sendJson(response, 200, { owned, gamePassId }, owned ? { 'Set-Cookie': `linex_payment=${createPaymentSession(userId)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=86400` } : {});
      })
      .catch((error) => sendJson(response, 502, { owned: false, error: error.message }));
    return;
  }

  if (requestPath === '/api/config' && request.method === 'PUT') {
    readRequestBody(request).then((updates) => {
      const nextConfig = { ...readConfig(), ...updates, updatedAt: new Date().toISOString() };
      fs.writeFileSync(configFile, JSON.stringify(nextConfig, null, 2));
      recordActivity({ person: 'Owner', action: 'Updated bot configuration', target: Object.keys(updates).join(', ') || 'Configuration' });
      sendJson(response, 200, nextConfig);
    }).catch((error) => sendJson(response, 400, { error: error.message }));
    return;
  }

  if (requestPath === '/dashboard' || requestPath === '/dashboard.html') {
    fs.readFile(dashboardPage, (error, content) => {
      if (error) {
        response.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
        response.end('Could not load the dashboard.');
        return;
      }
      const customerMode = new URL(request.url, `http://${request.headers.host || 'localhost'}`).searchParams.get('mode') === 'customer';
      const verifiedContent = content.toString().replace('window.__linexPaymentVerified = false;', `window.__linexPaymentVerified = ${customerMode && hasValidPaymentSession(request)};`);
      response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      response.end(verifiedContent);
    });
    return;
  }

  if (requestPath !== '/' && requestPath !== '/index.html') {
    response.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    response.end('Not found');
    return;
  }

  fs.readFile(page, (error, content) => {
    if (error) {
      response.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
      response.end('Could not load the dashboard.');
      return;
    }
    response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    response.end(content);
  });
}).listen(port, () => {
  console.log(`linex-systems is running at ${publicUrl}`);
});